public class Manager extends Employee {

	public void takeVacation() {
		throw new UnsupportedOperationException();
	}
}