public class Grunt extends Employee {


	public void doWork() {
		throw new UnsupportedOperationException();
	}
}