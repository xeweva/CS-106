package xmlvalidator;

public class XmlTag {
	public String name;
	public int index;


	public XmlTag(String name, int index) {
		super();
		this.name = name;
		this.index = index;
	}
}
